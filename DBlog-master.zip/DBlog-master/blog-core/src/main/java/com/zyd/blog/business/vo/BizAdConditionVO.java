
package com.zyd.blog.business.vo;

import com.zyd.blog.framework.object.BaseConditionVO;
import com.zyd.blog.business.entity.BizAdBo;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 
 *
 * @author generate by HouTu Generator
 * @version 1.0
 * @date 2021/10/27 16:43
 * @since 1.8
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class BizAdConditionVO extends BaseConditionVO {

}

