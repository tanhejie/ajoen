## 具体内容请参考 docs/docker/mysql/init_data.sql 文件
